--
-- Database: `qltbn`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `Username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`Username`, `Password`, `ID`) VALUES
('phi', '123', 'NA258'),
('long', '123', 'TC857');

-- --------------------------------------------------------

--
-- Table structure for table `accounta`
--

CREATE TABLE `accounta` (
  `Username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `accounta`
--

INSERT INTO `accounta` (`Username`, `Password`, `ID`) VALUES
('admin', 'admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `borrowde`
--

CREATE TABLE `borrowde` (
  `IDEm` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `NameEm` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FullName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Project` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `QuantityEm` int(11) NOT NULL,
  `ConfirmEm` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `IDUS` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `borrowde`
--

INSERT INTO `borrowde` (`IDEm`, `NameEm`, `FullName`, `Project`, `Status`, `QuantityEm`, `ConfirmEm`, `Type`, `IDUS`) VALUES
('ADue', 'Ardunio Due', 'Tran Ba Long', '', 'Good', 0, 'Wait Receive', 'Card', 'TC857'),
('COPC2', 'Camera Orange Pi CSI 2MP', 'Tran Ba Long', '', 'Good', 3, 'Pending', 'Card', 'TC857'),
('NP2F', 'Nano Pi 2 Fire', 'Tran Ba Long', '', 'Good', 10, 'Received', 'Chip', 'TC857'),
('NPM1', 'Nano Pi M1', 'Tran Ba Long', '', 'Normal', 5, 'Received', 'Main Board', 'TC857'),
('ADue', 'Ardunio Due', 'Nguyen Dinh Phi', '', 'Good', 5, 'Received', 'Card', 'NA258'),
('COPC2', 'Camera Orange Pi CSI 2MP', 'Nguyen Dinh Phi', '', 'Good', 8, 'Received', 'Card', 'NA258'),
('NPM1', 'Nano Pi M1', 'Nguyen Dinh Phi', '', 'Good', 22, 'Pending', 'Main Board', 'NA258'),
('CRPV5', 'Camera Raspberry Pi V1 5MP', 'Nguyen Dinh Phi', '', 'Good', 10, 'Pending', 'Card', 'NA258'),
('NPM1', 'Nano Pi M1', 'Nguyen Dinh Phi', '', 'Normal', 2, 'Pending', 'Main Board', 'NA258'),
('NPM3', 'Nano Pi M3', 'Nguyen Dinh Phi', '123', 'Good', 37, 'Pending', 'Main Board', 'NA258'),
('CRPV5', 'Camera Raspberry Pi V1 5MP', 'Nguyen Dinh Phi', '', 'Normal', 1, 'Pending', 'Card', 'NA258');

-- --------------------------------------------------------

--
-- Table structure for table `embedded`
--

CREATE TABLE `embedded` (
  `IDEm` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `NameEm` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FunctionEm` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `StatusEm` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `QuantityEm` int(11) NOT NULL,
  `Type` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `embedded`
--

INSERT INTO `embedded` (`IDEm`, `NameEm`, `FunctionEm`, `StatusEm`, `QuantityEm`, `Type`) VALUES
('NPM3', 'Nano Pi M3', 'Run on operating system android and linux', 'Good', 0, 'Main Board'),
('ADue', 'Ardunio Due', 'Driver DMA', 'Good', 79, 'Card'),
('COPC2', 'Camera Orange Pi CSI 2MP', 'Support camera slot', 'Good', 30, 'Card'),
('CRPV5', 'Camera Raspberry Pi V1 5MP', 'Good image quality', 'Good', 40, 'Card'),
('NP2F', 'Nano Pi 2 Fire', 'Touch creen connection', 'Good', 90, 'Chip'),
('NPM1', 'Nano Pi M1', 'Use for Linux', 'Good', 2, 'Main Board'),
('ADue', 'Ardunio Due', 'Driver DMA', 'Normal', 0, 'Card'),
('ADue', 'Ardunio Due', 'Driver DMA', 'Bad', 2, 'Card'),
('CRPV5', 'Camera Raspberry Pi V1 5MP', 'Good image quality', 'Normal', 1, 'Card'),
('CRPV5', 'Camera Raspberry Pi V1 5MP', 'Good image quality', 'Bad', 2, 'Card'),
('NPM1', 'Nano Pi M1', 'Use for Linux', 'Normal', 2, 'Main Board'),
('NPM1', 'Nano Pi M1', 'Use for Linux', 'Bad', 11, 'Main Board'),
('COPC2', 'Camera Orange Pi CSI 2MP', 'Support camera slot', 'Bad', 0, 'Card');

-- --------------------------------------------------------

--
-- Table structure for table `infomem`
--

CREATE TABLE `infomem` (
  `ID` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `Username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FullName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Address` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Gender` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `DOB` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `infomem`
--

INSERT INTO `infomem` (`ID`, `Username`, `Password`, `FullName`, `Address`, `Email`, `Gender`, `DOB`) VALUES
('NA258', 'phi', '123', 'Nguyen Dinh Phi', 'An Giang', 'phi@gmail.com', 'Female', '1988-03-03'),
('TC857', 'long', '123', 'Tran Ba Long', 'Can Tho', 'long@gmail.com', 'Female', '1996-03-01');

-- --------------------------------------------------------

--
-- Table structure for table `remember`
--

CREATE TABLE `remember` (
  `Username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `remember`
--

INSERT INTO `remember` (`Username`, `Password`, `Status`, `ID`) VALUES
('phi', '123', 'Yes', 'NA258'),
('long', '123', 'No', 'TC857');

-- --------------------------------------------------------

--
-- Table structure for table `remembera`
--

CREATE TABLE `remembera` (
  `Username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `remembera`
--

INSERT INTO `remembera` (`Username`, `Password`, `Status`, `ID`) VALUES
('admin', 'admin', 'Yes', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `accounta`
--
ALTER TABLE `accounta`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `infomem`
--
ALTER TABLE `infomem`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `remember`
--
ALTER TABLE `remember`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `remembera`
--
ALTER TABLE `remembera`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `remembera`
--
ALTER TABLE `remembera`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
